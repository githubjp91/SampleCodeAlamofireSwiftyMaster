# AlamofireWithSwiftyJSON
Sample of Alamofire with SwiftyJSON

Alamofire 4.x
Swift 3
Xcode 8
iOS 10

For complete tutorial visit : http://ashishkakkad.com/2015/10/how-to-use-alamofire-and-swiftyjson-with-swift/
